#ifndef Credentials_h
#define Credentials_h

char ssid[] = "tcc";        // your network SSID (name)
char pass[] = "12345678";        // your network password

char user[]         = "douglas.avanti";              // MySQL user login username
char password[]     = "!.Qlvv]ZqMO.]GZ2";          // MySQL user login password

#endif    //Credentials_h